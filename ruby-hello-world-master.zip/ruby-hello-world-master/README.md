This is a sample openshift v3 application repository.  

For instructions on how to use it, please see: https://github.com/openshift/origin/blob/master/examples/sample-app/README.md
